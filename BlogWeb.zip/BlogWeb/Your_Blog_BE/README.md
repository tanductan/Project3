Backend for app your blog
Run app:
start: npm start
nodemon: npm run dev