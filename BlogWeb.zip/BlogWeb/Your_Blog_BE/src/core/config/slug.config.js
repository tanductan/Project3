const slugOptions = {
    separator: "-",
    lang: "en",
    truncate: 120
}
module.exports = slugOptions;